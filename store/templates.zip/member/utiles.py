# in a utils.py file or any appropriate module
def is_user_authenticated(user):
    return user.is_authenticated